This has moved to [Run Koa.js on Google App Engine Flexible Environment](https://cloud.google.com/community/tutorials/run-koajs-on-google-app-engine).
