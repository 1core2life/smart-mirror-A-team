## MongoDB on Google App Engine

> [MongoDB][1] is an open source (AGPL licensed), NoSQL document database.

Read the [MongoDB on App Engine Tutorial][2] for how to run and deploy this sample
app.

You can also read the [node_mongodb documentation][3].

[1]: http://mongodb.org/
[2]: https://cloud.google.com/nodejs/resources/databases/mongodb
[3]: http://mongodb.github.io/node-mongodb-native/
