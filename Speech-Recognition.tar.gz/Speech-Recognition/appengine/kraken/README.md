This has moved to [Run Kraken.js on Google App Engine Flexible Environment](https://cloud.google.com/community/tutorials/run-krakenjs-on-google-app-engine).
