This has moved to [EDIT ON GITHUB  REPORT ISSUE  PAGE HISTORY
Run Restify.js on Google App Engine Flexible Environment](https://cloud.google.com/community/tutorials/run-restifyjs-on-google-app-engine).
