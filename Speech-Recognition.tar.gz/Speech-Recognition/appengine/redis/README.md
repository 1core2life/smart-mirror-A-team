## Redis on Google App Engine

> [Redis][1] is an open source (BSD licensed), in-memory data structure store,
used as database, cache and message broker.

Read the [Redis on App Engine Tutorial][2] for how to run and deploy this sample
app.

You can also read the [node_redis documentation][3].

[1]: http://redis.io/
[2]: https://cloud.google.com/nodejs/resources/databases/redis
[3]: https://github.com/NodeRedis/node_redis
