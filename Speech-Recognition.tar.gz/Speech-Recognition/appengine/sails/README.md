This has moved to [Run Sails.js on Google App Engine Flexible Environment](https://cloud.google.com/community/tutorials/run-sailsjs-on-google-app-engine).
