This has moved to [Webpack on App Engine Flexible Environment](https://cloud.google.com/community/tutorials/appengine-nodejs-webpack).
