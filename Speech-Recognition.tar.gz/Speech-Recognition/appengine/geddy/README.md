This has moved to [Run Geddy.js on Google App Engine Flexible Environment](https://cloud.google.com/community/tutorials/run-geddyjs-on-google-app-engine).
