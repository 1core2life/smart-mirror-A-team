This has moved to [Run Hapi.js on Google App Engine Flexible Environment](https://cloud.google.com/community/tutorials/run-hapijs-on-google-app-engine).
