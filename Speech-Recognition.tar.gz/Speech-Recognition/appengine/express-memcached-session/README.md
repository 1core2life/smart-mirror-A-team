This has moved to [Use Memcache for Sessions with Express.js on Google App Engine Flexible Environment](https://cloud.google.com/community/tutorials/express-memcached-session-appengine).
