This has been removed in favor of [Install Bower dependencies on Google App Engine Flexible Environment](https://cloud.google.com/community/tutorials/install-bower-dependencies-on-google-app-engine).
