This has moved to [Extending the Node.js Runtime of the Google App Engine Flexible Environment](https://cloud.google.com/community/tutorials/extending-google-appengine-flexible-nodejs-runtime).
