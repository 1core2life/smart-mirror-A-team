This has moved to [Run Express.js on Google App Engine Flexible Environment](https://cloud.google.com/community/tutorials/run-expressjs-on-google-app-engine).
