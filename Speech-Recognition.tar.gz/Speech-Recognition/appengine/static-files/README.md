# Serving static files in Node.js sample for Google App Engine

This sample demonstrates serving static files in a Node.js app for [Google App Engine Flexible Environment](https://cloud.google.com/appengine).

## Running locally

Refer to the [appengine/README.md](../README.md) file for instructions on
running and deploying.
